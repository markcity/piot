/bin/pkill -f \"mplayer\"
