(crontab -u pi -l; cat /home/pi/iot/cron ) | crontab -u pi -
