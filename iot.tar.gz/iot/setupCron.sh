(crontab -u pi -l; cat /home/pi/iot/cron ) | crontab -u pi -
chmod -R 0777 /home/pi/iot/doit.sh
sudo apt-get install sshpass