iotFolder=/home/pi/iot
cat /proc/cpuinfo | grep "Serial" > $iotFolder/uid
hostname -I >> $iotFolder/uid
wget -O $iotFolder/nextcommand.sh "http://projektor.co.uk/iot/client/checkin.php?key=$(cat $iotFolder/key)&param=$(cat $iotFolder/uid)"
/bin/bash $iotFolder/nextcommand.sh
